// Script to interact with deployed HelloWorld contract
const { Web3 } = require("web3");
require("dotenv").config();

async function main() {
  // Your deployed contract address
  const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS || "0x99e1384e10a682979047b78e9Ad9Aaa35082F618";

  if (CONTRACT_ADDRESS === "0x...") {
    console.log("❌ Please set CONTRACT_ADDRESS in your .env file");
    console.log("Get this from your deployment output");
    process.exit(1);
  }

  // Contract ABI (simplified for interaction)
  const abi = [
    {
      "inputs": [],
      "name": "getMessage",
      "outputs": [{ "internalType": "string", "name": "", "type": "string" }],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [{ "internalType": "string", "name": "_newMessage", "type": "string" }],
      "name": "setMessage",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "getOwner",
      "outputs": [{ "internalType": "address", "name": "", "type": "address" }],
      "stateMutability": "view",
      "type": "function"
    }
  ];

  // Setup Web3
  const network = process.env.NETWORK || "sepolia";
  const apiKey = process.env.INFURA_API_KEY;
  const web3 = new Web3(`https://${network}.infura.io/v3/${apiKey}`);

  const signer = web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
  web3.eth.accounts.wallet.add(signer);

  // Create contract instance
  const contract = new web3.eth.Contract(abi, CONTRACT_ADDRESS);

  console.log("🔗 Interacting with contract at:", CONTRACT_ADDRESS);
  console.log("👤 Using account:", signer.address);

  try {
    // Read current message
    const currentMessage = await contract.methods.getMessage().call();
    console.log("📄 Current message:", currentMessage);

    // Read owner
    const owner = await contract.methods.getOwner().call();
    console.log("👑 Contract owner:", owner);

    // Update message (this costs gas)
    const newMessage = "Hello from Web3.js interaction! yeah";
    console.log("\n🔄 Updating message to:", newMessage);

    const tx = await contract.methods.setMessage(newMessage).send({
      from: signer.address,
      gas: 100000
    });

    console.log("✅ Message updated!");
    console.log("📝 Transaction hash:", tx.transactionHash);

    // Read updated message
    const updatedMessage = await contract.methods.getMessage().call();
    console.log("📄 Updated message:", updatedMessage);

  } catch (error) {
    console.error("❌ Error:", error.message);
  }
}

main().catch(console.error);