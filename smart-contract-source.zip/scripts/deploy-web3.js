// Web3.js deployment script following testnet.md guide
const { Web3 } = require("web3");
const fs = require("fs");
require("dotenv").config();

async function main() {
  // Load contract artifacts
  const contractPath = "./artifacts/contracts/HelloWorld.sol/HelloWorld.json";
  const { abi, bytecode } = JSON.parse(fs.readFileSync(contractPath));

  // Network configuration
  const network = process.env.NETWORK || "sepolia";
  const apiKey = process.env.INFURA_API_KEY;
  
  if (!apiKey) {
    console.error("❌ INFURA_API_KEY not found in .env file");
    console.log("Please add your Infura API key to the .env file");
    process.exit(1);
  }

  if (!process.env.PRIVATE_KEY) {
    console.error("❌ PRIVATE_KEY not found in .env file");
    console.log("Please add your wallet private key to the .env file");
    process.exit(1);
  }

  // Initialize Web3
  const web3 = new Web3(
    new Web3.providers.HttpProvider(`https://${network}.infura.io/v3/${apiKey}`)
  );

  console.log("🌐 Connected to", network, "network");

  // Setup signer account
  const signer = web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
  web3.eth.accounts.wallet.add(signer);

  console.log("👤 Deploying from account:", signer.address);

  // Check balance
  const balance = await web3.eth.getBalance(signer.address);
  const balanceEth = web3.utils.fromWei(balance, 'ether');
  console.log("💰 Account balance:", balanceEth, "ETH");

  if (parseFloat(balanceEth) < 0.01) {
    console.warn("⚠️  Low balance! You may need more testnet ETH from a faucet");
    console.log("Get Sepolia ETH from: https://sepoliafaucet.com/");
  }

  // Deploy contract
  console.log("🚀 Deploying HelloWorld contract...");
  
  const contract = new web3.eth.Contract(abi);
  contract.options.data = bytecode;

  try {
    const deployedContract = await contract.deploy()
      .send({ 
        from: signer.address, 
        gas: 2000000,
        gasPrice: await web3.eth.getGasPrice()
      })
      .once("transactionHash", (txhash) => {
        console.log("📝 Transaction hash:", txhash);
        console.log("🔍 View on Etherscan:", `https://sepolia.etherscan.io/tx/${txhash}`);
      });

    console.log("✅ Contract deployed successfully!");
    console.log("📍 Contract address:", deployedContract.options.address);
    console.log("🔍 View contract:", `https://sepolia.etherscan.io/address/${deployedContract.options.address}`);

    // Test the deployed contract
    console.log("\n🧪 Testing deployed contract...");
    const message = await deployedContract.methods.getMessage().call();
    console.log("📄 Initial message:", message);
    
    const owner = await deployedContract.methods.getOwner().call();
    console.log("👑 Contract owner:", owner);

  } catch (error) {
    console.error("❌ Deployment failed:", error.message);
    process.exit(1);
  }
}

main()
  .then(() => {
    console.log("\n🎉 Deployment completed successfully!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("💥 Error:", error);
    process.exit(1);
  });