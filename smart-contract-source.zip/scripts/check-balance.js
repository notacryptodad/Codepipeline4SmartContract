// Script to check wallet balance on Sepolia
const { Web3 } = require("web3");
require("dotenv").config();

async function checkBalance() {
  // Setup Web3
  const network = process.env.NETWORK || "sepolia";
  const apiKey = process.env.INFURA_API_KEY;
  const web3 = new Web3(`https://${network}.infura.io/v3/${apiKey}`);

  // Get account from private key
  const signer = web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
  const address = signer.address;

  console.log("🔍 Checking balance for:", address);
  console.log("🌐 Network:", network);

  try {
    // Get balance in Wei
    const balanceWei = await web3.eth.getBalance(address);
    
    // Convert to ETH
    const balanceEth = web3.utils.fromWei(balanceWei, 'ether');
    
    console.log("💰 Balance:", balanceEth, "ETH");
    console.log("💰 Balance (Wei):", balanceWei);

    // Also get latest block to confirm connection
    const blockNumber = await web3.eth.getBlockNumber();
    console.log("📦 Latest block:", blockNumber);

  } catch (error) {
    console.error("❌ Error checking balance:", error.message);
  }
}

checkBalance().catch(console.error);