// Deploy multi-owner contracts
const { Web3 } = require("web3");
require("dotenv").config();

async function deployMultiOwner() {
    const network = process.env.NETWORK || "sepolia";
    const apiKey = process.env.INFURA_API_KEY;
    const web3 = new Web3(`https://${network}.infura.io/v3/${apiKey}`);

    const signer = web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
    web3.eth.accounts.wallet.add(signer);

    // Define multiple owners (replace with actual addresses)
    const owners = [
        signer.address, // Your address
        "0x742d35Cc6634C0532925a3b8D404fddF4b34c451", // Replace with actual address
        "0x8ba1f109551bD432803012645Hac136c30C6c3c2" // Replace with actual address
    ];

    console.log("🚀 Deploying MultiOwnerHelloWorld...");
    console.log("👥 Owners:", owners);

    try {
        // Read compiled contract
        const fs = require('fs');
        const contractJson = JSON.parse(
            fs.readFileSync('./artifacts/contracts/MultiOwnerHelloWorld.sol/MultiOwnerHelloWorld.json', 'utf8')
        );

        const contract = new web3.eth.Contract(contractJson.abi);
        
        const deployTx = contract.deploy({
            data: contractJson.bytecode,
            arguments: [owners] // Pass owners array to constructor
        });

        const gas = await deployTx.estimateGas({ from: signer.address });
        console.log("⛽ Estimated gas:", gas);

        const result = await deployTx.send({
            from: signer.address,
            gas: Math.floor(gas * 1.2) // Add 20% buffer
        });

        console.log("✅ MultiOwnerHelloWorld deployed!");
        console.log("📍 Contract address:", result.options.address);
        console.log("🔗 Transaction hash:", result.transactionHash);

        return result.options.address;

    } catch (error) {
        console.error("❌ Deployment failed:", error.message);
    }
}

async function deployMultisig() {
    const network = process.env.NETWORK || "sepolia";
    const apiKey = process.env.INFURA_API_KEY;
    const web3 = new Web3(`https://${network}.infura.io/v3/${apiKey}`);

    const signer = web3.eth.accounts.privateKeyToAccount(process.env.PRIVATE_KEY);
    web3.eth.accounts.wallet.add(signer);

    // Define multiple owners and required confirmations
    const owners = [
        signer.address,
        "0x742d35Cc6634C0532925a3b8D404fddF4b34c451",
        "0x8ba1f109551bD432803012645Hac136c30C6c3c2"
    ];
    const requiredConfirmations = 2; // 2 out of 3 must agree

    console.log("🚀 Deploying MultisigHelloWorld...");
    console.log("👥 Owners:", owners);
    console.log("✅ Required confirmations:", requiredConfirmations);

    try {
        const fs = require('fs');
        const contractJson = JSON.parse(
            fs.readFileSync('./artifacts/contracts/MultisigHelloWorld.sol/MultisigHelloWorld.json', 'utf8')
        );

        const contract = new web3.eth.Contract(contractJson.abi);
        
        const deployTx = contract.deploy({
            data: contractJson.bytecode,
            arguments: [owners, requiredConfirmations]
        });

        const gas = await deployTx.estimateGas({ from: signer.address });
        console.log("⛽ Estimated gas:", gas);

        const result = await deployTx.send({
            from: signer.address,
            gas: Math.floor(gas * 1.2)
        });

        console.log("✅ MultisigHelloWorld deployed!");
        console.log("📍 Contract address:", result.options.address);
        console.log("🔗 Transaction hash:", result.transactionHash);

        return result.options.address;

    } catch (error) {
        console.error("❌ Deployment failed:", error.message);
    }
}

// Choose which one to deploy
const contractType = process.argv[2] || "multi";

if (contractType === "multi") {
    deployMultiOwner().catch(console.error);
} else if (contractType === "multisig") {
    deployMultisig().catch(console.error);
} else {
    console.log("Usage: node scripts/deploy-multi-owner.js [multi|multisig]");
}