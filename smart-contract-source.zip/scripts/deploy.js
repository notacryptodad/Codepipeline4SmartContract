const hre = require("hardhat");

async function main() {
  console.log("Deploying HelloWorld contract...");
  
  const HelloWorld = await hre.ethers.getContractFactory("HelloWorld");
  const helloWorld = await HelloWorld.deploy();
  
  await helloWorld.waitForDeployment();
  
  const contractAddress = await helloWorld.getAddress();
  console.log("HelloWorld deployed to:", contractAddress);
  
  // Verify the initial message
  const initialMessage = await helloWorld.getMessage();
  console.log("Initial message:", initialMessage);
  
  console.log("Contract owner:", await helloWorld.getOwner());
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });