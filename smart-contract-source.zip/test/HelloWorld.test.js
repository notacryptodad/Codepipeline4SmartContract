const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HelloWorld", function () {
  let helloWorld;
  let owner;
  let addr1;

  beforeEach(async function () {
    [owner, addr1] = await ethers.getSigners();
    const HelloWorld = await ethers.getContractFactory("HelloWorld");
    helloWorld = await HelloWorld.deploy();
    await helloWorld.waitForDeployment();
  });

  it("Should return the initial message", async function () {
    expect(await helloWorld.getMessage()).to.equal("Hello, World!");
  });

  it("Should set the correct owner", async function () {
    expect(await helloWorld.getOwner()).to.equal(owner.address);
  });

  it("Should allow changing the message", async function () {
    const newMessage = "Hello, Ethereum!";
    await helloWorld.setMessage(newMessage);
    expect(await helloWorld.getMessage()).to.equal(newMessage);
  });

  it("Should emit MessageChanged event", async function () {
    const newMessage = "Hello, Blockchain!";
    await expect(helloWorld.setMessage(newMessage))
      .to.emit(helloWorld, "MessageChanged")
      .withArgs(newMessage, owner.address);
  });
});