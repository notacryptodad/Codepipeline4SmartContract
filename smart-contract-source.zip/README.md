# HelloWorld Smart Contract

A simple HelloWorld smart contract for Ethereum built with Hardhat and Web3.js, following best practices for testnet deployment.

## Prerequisites

- **MetaMask Wallet**: Install MetaMask extension and create an Ethereum account
- **Testnet ETH**: Get free Sepolia ETH from [Sepolia Faucet](https://sepoliafaucet.com/)
- **Infura Account**: Register at [Infura.io](https://infura.io/) and get your API key
- **Node.js**: Version 16+ recommended

## Setup

1. **Install dependencies:**
```bash
npm install
```

2. **Configure environment:**
```bash
cp .env.example .env
```

3. **Edit `.env` file with your credentials:**
```bash
INFURA_API_KEY=your_infura_api_key_here
PRIVATE_KEY=your_metamask_private_key_here
NETWORK=sepolia
```

### Getting Your Credentials

#### Infura API Key:
1. Go to [Infura.io](https://infura.io/) and create account
2. Create new API key for "Web3 API"
3. Copy your API key

#### MetaMask Private Key:
1. Open MetaMask → Account Details → Export Private Key
2. **⚠️ Keep this secure and never share it!**

#### Testnet ETH:
- Visit [Sepolia Faucet](https://sepoliafaucet.com/)
- Enter your wallet address to get free test ETH

## Usage

### Compile the contract:
```bash
npm run compile
```

### Run tests:
```bash
npm run test
```

### Deploy to Sepolia testnet:

**Option 1: Using Hardhat (Recommended)**
```bash
npm run deploy:sepolia
```

**Option 2: Using Web3.js (Following testnet.md guide)**
```bash
npm run deploy:web3
```

## Contract Features

- Store and retrieve a message string
- Change the message (anyone can call)
- Track contract owner
- Emit events when message changes
- Gas optimized for testnet deployment

## Deployment Output

After successful deployment, you'll see:
- Transaction hash
- Contract address
- Etherscan links for verification
- Initial contract state

## Verification

Once deployed, you can:
- View your contract on [Sepolia Etherscan](https://sepolia.etherscan.io/)
- Interact with it using Remix IDE
- Call contract methods from your scripts

## Troubleshooting

- **Low balance error**: Get more Sepolia ETH from faucet
- **Network issues**: Try the public RPC option in hardhat.config.js
- **Gas estimation failed**: Check your private key and network connection

## Security Notes

- Never commit your `.env` file to version control
- Keep your private key secure
- Only use testnet for development
- Test thoroughly before mainnet deployment