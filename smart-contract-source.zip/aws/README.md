# AWS CodePipeline for HelloWorld Smart Contract

This directory contains AWS infrastructure code to set up a complete CI/CD pipeline for automatically building, testing, and deploying your HelloWorld smart contract to Ethereum Sepolia testnet.

## 🏗️ Architecture

```
GitHub Repository → AWS CodePipeline → AWS CodeBuild → Ethereum Sepolia Testnet
```

### Components:
- **AWS CodePipeline**: Orchestrates the CI/CD workflow
- **AWS CodeBuild**: Builds, tests, and deploys the smart contract
- **AWS Systems Manager Parameter Store**: Securely stores sensitive data (API keys, private keys)
- **AWS S3**: Stores build artifacts
- **AWS CloudFormation**: Infrastructure as Code

## 🚀 Quick Setup

### Prerequisites:
1. **AWS Account** with appropriate permissions
2. **AWS CLI** installed and configured
3. **GitHub Repository** with your smart contract code
4. **GitHub Personal Access Token** with `repo` permissions
5. **Infura API Key** for Ethereum network access
6. **Ethereum Wallet Private Key** for deployment

### Deploy the Pipeline:

```bash
# Make the script executable
chmod +x aws/scripts/deploy-pipeline.sh

# Run the deployment script
./aws/scripts/deploy-pipeline.sh
```

The script will prompt you for:
- GitHub username and repository
- Infura API key
- Ethereum private key
- GitHub personal access token

## 📋 What the Pipeline Does

### 1. **Source Stage**
- Monitors your GitHub repository for changes
- Triggers automatically on code push to main branch

### 2. **Build & Deploy Stage**
- Installs Node.js dependencies
- Compiles Solidity contracts
- Runs test suite
- Deploys to Sepolia testnet
- Saves deployment artifacts

### 3. **Outputs**
- Contract address on Sepolia
- Transaction hash
- Deployment timestamp
- Build artifacts in S3

## 🔧 Manual Operations

### Trigger Pipeline Manually:
```bash
./aws/scripts/trigger-pipeline.sh
```

### View Pipeline Status:
```bash
aws codepipeline get-pipeline-state --name helloworld-smart-contract-pipeline-smart-contract-pipeline
```

### Check Build Logs:
```bash
aws logs describe-log-groups --log-group-name-prefix /aws/codebuild/helloworld
```

## 🔐 Security Features

### Secure Storage:
- **Private keys** stored in AWS Systems Manager Parameter Store (encrypted)
- **API keys** stored securely with encryption at rest
- **GitHub tokens** stored in AWS Secrets Manager

### IAM Permissions:
- Least privilege access for all services
- Separate roles for CodePipeline and CodeBuild
- No hardcoded credentials in code

## 📊 Monitoring & Logging

### CloudWatch Integration:
- Build logs automatically sent to CloudWatch
- Pipeline execution history tracked
- Failed builds trigger notifications

### Artifacts:
- Compiled contracts stored in S3
- Deployment information saved as JSON
- Build cache for faster subsequent builds

## 🛠️ Customization

### Environment Variables:
Edit the CloudFormation template to add more environment variables:

```yaml
EnvironmentVariables:
  - Name: CUSTOM_VARIABLE
    Value: custom_value
```

### Different Networks:
To deploy to different networks, update the `NETWORK` environment variable in the buildspec.

### Notifications:
Add SNS topics to get notified of pipeline events:

```yaml
# Add to CloudFormation template
PipelineEventRule:
  Type: AWS::Events::Rule
  Properties:
    EventPattern:
      source: [aws.codepipeline]
      detail-type: [CodePipeline Pipeline Execution State Change]
```

## 💰 Cost Estimation

### Monthly Costs (approximate):
- **CodePipeline**: $1 per active pipeline
- **CodeBuild**: $0.005 per build minute (typically 2-3 minutes per build)
- **S3 Storage**: $0.023 per GB (minimal for artifacts)
- **Parameter Store**: Free for standard parameters
- **CloudWatch Logs**: $0.50 per GB ingested

**Estimated monthly cost**: $2-5 for typical usage

## 🚨 Troubleshooting

### Common Issues:

#### Build Fails with "Invalid Private Key":
- Ensure private key has `0x` prefix
- Verify key is 64 hex characters long

#### GitHub Connection Issues:
- Check GitHub token permissions
- Verify repository name and owner

#### Deployment Fails:
- Check Sepolia testnet ETH balance
- Verify Infura API key is valid
- Check network connectivity

#### Permission Errors:
- Ensure AWS user has necessary IAM permissions
- Check CloudFormation stack events for details

### Debug Commands:
```bash
# Check pipeline status
aws codepipeline get-pipeline-state --name PIPELINE_NAME

# View build logs
aws logs filter-log-events --log-group-name /aws/codebuild/PROJECT_NAME

# Check parameter store values
aws ssm get-parameter --name /smart-contract/infura-api-key --with-decryption
```

## 🔄 Pipeline Workflow

```mermaid
graph LR
    A[Code Push] --> B[GitHub Webhook]
    B --> C[CodePipeline Trigger]
    C --> D[CodeBuild Start]
    D --> E[Install Dependencies]
    E --> F[Compile Contracts]
    F --> G[Run Tests]
    G --> H[Deploy to Sepolia]
    H --> I[Save Artifacts]
    I --> J[Pipeline Complete]
```

## 📚 Additional Resources

- [AWS CodePipeline Documentation](https://docs.aws.amazon.com/codepipeline/)
- [AWS CodeBuild Documentation](https://docs.aws.amazon.com/codebuild/)
- [Hardhat Deployment Guide](https://hardhat.org/tutorial/deploying-to-a-live-network.html)
- [Ethereum Sepolia Testnet](https://sepolia.etherscan.io/)

## 🤝 Contributing

To modify the pipeline:
1. Update CloudFormation template in `aws/cloudformation/pipeline.yml`
2. Modify build commands in `buildspec.yml`
3. Test changes in a separate AWS account first
4. Deploy using the deployment script

## 📞 Support

For issues with:
- **AWS Infrastructure**: Check CloudFormation events and CloudWatch logs
- **Smart Contract Deployment**: Review Hardhat configuration and network settings
- **GitHub Integration**: Verify webhook configuration and token permissions