#!/bin/bash
# Quick script to package and upload source code to S3 and trigger pipeline

set -e

# Configuration - will be updated by deploy script
STACK_NAME="helloworld-smart-contract-s3-pipeline"
REGION="us-east-1"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${GREEN}📦 Packaging and Uploading Smart Contract Source Code${NC}"

# Get source bucket from CloudFormation stack
SOURCE_BUCKET=$(aws cloudformation describe-stacks \
    --stack-name $STACK_NAME \
    --region $REGION \
    --query 'Stacks[0].Outputs[?OutputKey==`SourceBucket`].OutputValue' \
    --output text 2>/dev/null)

if [ -z "$SOURCE_BUCKET" ]; then
    echo "❌ Pipeline not found. Make sure you've deployed the S3 pipeline first."
    echo "Run: npm run deploy:pipeline:s3"
    exit 1
fi

PIPELINE_NAME=$(aws cloudformation describe-stacks \
    --stack-name $STACK_NAME \
    --region $REGION \
    --query 'Stacks[0].Outputs[?OutputKey==`PipelineName`].OutputValue' \
    --output text)

TIMESTAMP=$(date +%Y%m%d-%H%M%S)

echo "Source Bucket: $SOURCE_BUCKET"
echo "Pipeline: $PIPELINE_NAME"

echo -e "${YELLOW}📦 Creating source code package...${NC}"
zip -r source-code.zip . \
    -x '*.git*' \
       'node_modules/*' \
       'aws/*' \
       '.env' \
       '*.zip' \
       'cache/*' \
       'artifacts/*' \
       '.DS_Store' \
       '*.log'

echo -e "${YELLOW}📤 Uploading to S3...${NC}"
aws s3 cp source-code.zip s3://$SOURCE_BUCKET/source-code.zip

echo -e "${YELLOW}📋 Creating backup with timestamp...${NC}"
aws s3 cp source-code.zip s3://$SOURCE_BUCKET/backups/source-code-$TIMESTAMP.zip

echo -e "${GREEN}✅ Upload complete! Pipeline should start automatically.${NC}"
echo ""
echo -e "${BLUE}🔗 Monitor Progress:${NC}"
echo "• Pipeline: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"
echo "• S3 Bucket: https://s3.console.aws.amazon.com/s3/buckets/$SOURCE_BUCKET"
echo ""
echo -e "${YELLOW}📊 Pipeline Status:${NC}"

# Wait a moment for S3 event to trigger
sleep 5

# Check if pipeline is running
PIPELINE_STATUS=$(aws codepipeline get-pipeline-state \
    --name $PIPELINE_NAME \
    --region $REGION \
    --query 'stageStates[0].latestExecution.status' \
    --output text 2>/dev/null || echo "Unknown")

echo "Current Status: $PIPELINE_STATUS"

if [ "$PIPELINE_STATUS" = "InProgress" ]; then
    echo -e "${GREEN}🚀 Pipeline is running!${NC}"
else
    echo -e "${YELLOW}⏳ Pipeline should start shortly...${NC}"
fi

# Cleanup
rm source-code.zip

echo ""
echo -e "${BLUE}💡 Next Steps:${NC}"
echo "1. Monitor the pipeline execution in AWS Console"
echo "2. Check CloudWatch logs for build details"
echo "3. View deployed contract on Sepolia Etherscan"
echo "4. Check deployment info in S3: s3://$SOURCE_BUCKET/deployments/"