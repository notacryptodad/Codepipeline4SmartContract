#!/bin/bash

# Script to manually trigger the AWS CodePipeline

set -e

STACK_NAME="helloworld-smart-contract-pipeline"
REGION="us-east-1"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🚀 Triggering Smart Contract Pipeline${NC}"

# Get pipeline name from CloudFormation stack
PIPELINE_NAME=$(aws cloudformation describe-stacks \
    --stack-name $STACK_NAME \
    --region $REGION \
    --query 'Stacks[0].Outputs[?OutputKey==`PipelineName`].OutputValue' \
    --output text)

if [ -z "$PIPELINE_NAME" ]; then
    echo "❌ Pipeline not found. Make sure the stack is deployed."
    exit 1
fi

echo "Pipeline Name: $PIPELINE_NAME"

# Start pipeline execution
EXECUTION_ID=$(aws codepipeline start-pipeline-execution \
    --name $PIPELINE_NAME \
    --region $REGION \
    --query 'pipelineExecutionId' \
    --output text)

echo -e "${GREEN}✅ Pipeline triggered successfully!${NC}"
echo "Execution ID: $EXECUTION_ID"
echo ""
echo -e "${YELLOW}📋 Monitor Progress:${NC}"
echo "• Console: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"
echo "• Execution: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/executions/$EXECUTION_ID/timeline"

# Watch pipeline status
echo ""
echo "Watching pipeline status..."
while true; do
    STATUS=$(aws codepipeline get-pipeline-execution \
        --pipeline-name $PIPELINE_NAME \
        --pipeline-execution-id $EXECUTION_ID \
        --region $REGION \
        --query 'pipelineExecution.status' \
        --output text)
    
    echo "Status: $STATUS"
    
    if [ "$STATUS" = "Succeeded" ]; then
        echo -e "${GREEN}🎉 Pipeline completed successfully!${NC}"
        break
    elif [ "$STATUS" = "Failed" ]; then
        echo "❌ Pipeline failed. Check the console for details."
        break
    elif [ "$STATUS" = "Stopped" ]; then
        echo "⏹️  Pipeline was stopped."
        break
    fi
    
    sleep 30
done