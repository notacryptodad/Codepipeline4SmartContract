#!/bin/bash

# Deploy Security-Focused CodePipeline for Smart Contract
# This script sets up a pipeline with manual security approval gates

set -e

echo "🔒 Smart Contract Security Pipeline Deployment"
echo "=============================================="

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to prompt for input
prompt_input() {
    local prompt="$1"
    local var_name="$2"
    local is_secret="$3"
    
    echo -e "${BLUE}$prompt${NC}"
    if [ "$is_secret" = "true" ]; then
        read -s input_value
        echo
    else
        read input_value
    fi
    
    if [ -z "$input_value" ]; then
        echo -e "${RED}Error: This field is required${NC}"
        exit 1
    fi
    
    eval "$var_name='$input_value'"
}

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo -e "${RED}Error: AWS CLI is not installed${NC}"
    echo "Please install AWS CLI: https://aws.amazon.com/cli/"
    exit 1
fi

# Check if user is logged in to AWS
if ! aws sts get-caller-identity &> /dev/null; then
    echo -e "${RED}Error: Not authenticated with AWS${NC}"
    echo "Please run: aws configure"
    exit 1
fi

echo -e "${GREEN}✓ AWS CLI is configured${NC}"

# Get user inputs
echo -e "${YELLOW}Please provide the following information:${NC}"
echo

prompt_input "GitHub Username:" GITHUB_OWNER false
prompt_input "GitHub Repository Name:" GITHUB_REPO false
prompt_input "GitHub Branch (default: main):" GITHUB_BRANCH false
GITHUB_BRANCH=${GITHUB_BRANCH:-main}

prompt_input "Security Team Email Address:" SECURITY_EMAIL false
prompt_input "New Contract Owner Address (0x...):" NEW_OWNER_ADDRESS false

echo
prompt_input "Infura API Key:" INFURA_API_KEY true
prompt_input "Ethereum Private Key (with 0x prefix):" PRIVATE_KEY true

echo
echo -e "${YELLOW}Checking for GitHub token in AWS Secrets Manager...${NC}"

# Check if GitHub token exists in Secrets Manager
if ! aws secretsmanager describe-secret --secret-id github-token &> /dev/null; then
    echo -e "${YELLOW}GitHub token not found. Creating secret...${NC}"
    prompt_input "GitHub Personal Access Token:" GITHUB_TOKEN true
    
    aws secretsmanager create-secret \
        --name github-token \
        --description "GitHub Personal Access Token for CodePipeline" \
        --secret-string "{\"token\":\"$GITHUB_TOKEN\"}"
    
    echo -e "${GREEN}✓ GitHub token stored in Secrets Manager${NC}"
else
    echo -e "${GREEN}✓ GitHub token already exists in Secrets Manager${NC}"
fi

# Generate stack name
STACK_NAME="smart-contract-security-pipeline"

echo
echo -e "${BLUE}Deployment Configuration:${NC}"
echo "Stack Name: $STACK_NAME"
echo "GitHub: $GITHUB_OWNER/$GITHUB_REPO ($GITHUB_BRANCH)"
echo "Security Email: $SECURITY_EMAIL"
echo "New Owner: $NEW_OWNER_ADDRESS"
echo

read -p "Deploy with these settings? (y/N): " confirm
if [[ ! $confirm =~ ^[Yy]$ ]]; then
    echo "Deployment cancelled"
    exit 0
fi

echo
echo -e "${YELLOW}Deploying CloudFormation stack...${NC}"

# Deploy the CloudFormation stack
aws cloudformation deploy \
    --template-file aws/cloudformation/security-pipeline.yml \
    --stack-name "$STACK_NAME" \
    --parameter-overrides \
        GitHubOwner="$GITHUB_OWNER" \
        GitHubRepo="$GITHUB_REPO" \
        GitHubBranch="$GITHUB_BRANCH" \
        InfuraApiKey="$INFURA_API_KEY" \
        PrivateKey="$PRIVATE_KEY" \
        SecurityTeamEmail="$SECURITY_EMAIL" \
        NewOwnerAddress="$NEW_OWNER_ADDRESS" \
    --capabilities CAPABILITY_IAM \
    --no-fail-on-empty-changeset

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Security pipeline deployed successfully!${NC}"
    echo
    
    # Get outputs
    PIPELINE_NAME=$(aws cloudformation describe-stacks \
        --stack-name "$STACK_NAME" \
        --query 'Stacks[0].Outputs[?OutputKey==`PipelineName`].OutputValue' \
        --output text)
    
    CONSOLE_URL=$(aws cloudformation describe-stacks \
        --stack-name "$STACK_NAME" \
        --query 'Stacks[0].Outputs[?OutputKey==`PipelineConsoleUrl`].OutputValue' \
        --output text)
    
    echo -e "${BLUE}📋 Pipeline Information:${NC}"
    echo "Pipeline Name: $PIPELINE_NAME"
    echo "Console URL: $CONSOLE_URL"
    echo
    
    echo -e "${BLUE}🔄 Pipeline Flow:${NC}"
    echo "1. Source: Monitors GitHub repository"
    echo "2. Build & Deploy: Compiles and deploys contract"
    echo "3. Security Notification: Alerts security team"
    echo "4. Manual Approval: Security team reviews and approves"
    echo "5. Ownership Transfer: Transfers contract ownership"
    echo "6. Final Confirmation: Security team confirms transfer"
    echo
    
    echo -e "${YELLOW}📧 Security Team Setup:${NC}"
    echo "• Security team will receive email notifications"
    echo "• Manual approval required at two stages"
    echo "• Pipeline stops if security review fails"
    echo "• Full audit trail maintained in DynamoDB"
    echo
    
    echo -e "${GREEN}🚀 Next Steps:${NC}"
    echo "1. Push code changes to trigger the pipeline"
    echo "2. Monitor pipeline progress in AWS Console"
    echo "3. Security team will receive notifications"
    echo "4. Approve/reject at security checkpoints"
    echo
    
    echo -e "${BLUE}Pipeline Console: $CONSOLE_URL${NC}"
    
else
    echo -e "${RED}❌ Deployment failed${NC}"
    exit 1
fi