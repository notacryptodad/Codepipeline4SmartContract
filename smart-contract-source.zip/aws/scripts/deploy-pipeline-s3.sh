#!/bin/bash

# AWS CodePipeline Deployment Script with S3 Source for HelloWorld Smart Contract
# This script deploys the AWS infrastructure for CI/CD pipeline using S3 as source

set -e

# Configuration
STACK_NAME="helloworld-smart-contract-s3-pipeline"
REGION="us-east-1"
TEMPLATE_FILE="aws/cloudformation/pipeline-s3.yml"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Deploying HelloWorld Smart Contract Pipeline (S3 Source)${NC}"
echo "=============================================================="

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo -e "${RED}❌ AWS CLI is not installed. Please install it first.${NC}"
    exit 1
fi

# Check if user is logged in to AWS
if ! aws sts get-caller-identity &> /dev/null; then
    echo -e "${RED}❌ AWS credentials not configured. Please run 'aws configure' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ AWS CLI configured${NC}"

# Prompt for parameters
echo -e "${YELLOW}📝 Please provide the following information:${NC}"

read -s -p "Infura API Key: " INFURA_API_KEY
echo

read -s -p "Ethereum Private Key (with 0x prefix): " PRIVATE_KEY
echo

read -p "Source S3 Bucket Name [smart-contract-source-code]: " SOURCE_BUCKET_NAME
SOURCE_BUCKET_NAME=${SOURCE_BUCKET_NAME:-smart-contract-source-code}

# Validate inputs
if [[ -z "$INFURA_API_KEY" || -z "$PRIVATE_KEY" ]]; then
    echo -e "${RED}❌ All parameters are required${NC}"
    exit 1
fi

if [[ ! "$PRIVATE_KEY" =~ ^0x[a-fA-F0-9]{64}$ ]]; then
    echo -e "${RED}❌ Invalid private key format. Must be 64 hex characters with 0x prefix${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Parameters validated${NC}"

# Deploy CloudFormation stack
echo -e "${YELLOW}☁️  Deploying CloudFormation stack...${NC}"

aws cloudformation deploy \
    --template-file $TEMPLATE_FILE \
    --stack-name $STACK_NAME \
    --parameter-overrides \
        InfuraApiKey=$INFURA_API_KEY \
        PrivateKey=$PRIVATE_KEY \
        SourceBucketName=$SOURCE_BUCKET_NAME \
    --capabilities CAPABILITY_IAM \
    --region $REGION

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Pipeline deployed successfully!${NC}"
    
    # Get outputs
    PIPELINE_NAME=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`PipelineName`].OutputValue' \
        --output text)
    
    SOURCE_BUCKET=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`SourceBucket`].OutputValue' \
        --output text)
    
    ARTIFACTS_BUCKET=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`ArtifactsBucket`].OutputValue' \
        --output text)
    
    UPLOAD_COMMAND=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`UploadCommand`].OutputValue' \
        --output text)
    
    echo ""
    echo -e "${GREEN}🎉 Deployment Complete!${NC}"
    echo "========================"
    echo "Pipeline Name: $PIPELINE_NAME"
    echo "Source Bucket: $SOURCE_BUCKET"
    echo "Artifacts Bucket: $ARTIFACTS_BUCKET"
    echo "Region: $REGION"
    echo ""
    echo -e "${BLUE}📦 How to Deploy Your Smart Contract:${NC}"
    echo ""
    echo -e "${YELLOW}Step 1: Create source code package${NC}"
    echo "zip -r source-code.zip . -x '*.git*' 'node_modules/*' 'aws/*' '.env'"
    echo ""
    echo -e "${YELLOW}Step 2: Upload to S3 (triggers pipeline automatically)${NC}"
    echo "$UPLOAD_COMMAND"
    echo ""
    echo -e "${YELLOW}Step 3: Monitor the pipeline${NC}"
    echo "The pipeline will automatically start when you upload the zip file!"
    echo ""
    echo -e "${GREEN}🔗 Useful Links:${NC}"
    echo "• Pipeline Console: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"
    echo "• Source S3 Bucket: https://s3.console.aws.amazon.com/s3/buckets/$SOURCE_BUCKET"
    echo "• CloudFormation Stack: https://console.aws.amazon.com/cloudformation/home?region=$REGION#/stacks/stackinfo?stackId=$STACK_NAME"
    echo ""
    echo -e "${BLUE}💡 Pro Tips:${NC}"
    echo "• Upload different versions with timestamps: source-code-v1.0.zip"
    echo "• Check deployment history in S3: s3://$SOURCE_BUCKET/deployments/"
    echo "• Pipeline triggers automatically on any upload to source-code.zip"
    echo "• Use 'npm run upload:source' for quick uploads (command will be added)"
    
    # Create upload script
    cat > aws/scripts/upload-source.sh << EOF
#!/bin/bash
# Quick script to package and upload source code

set -e

SOURCE_BUCKET="$SOURCE_BUCKET"
TIMESTAMP=\$(date +%Y%m%d-%H%M%S)

echo "📦 Creating source code package..."
zip -r source-code.zip . -x '*.git*' 'node_modules/*' 'aws/*' '.env' '*.zip'

echo "📤 Uploading to S3..."
aws s3 cp source-code.zip s3://\$SOURCE_BUCKET/source-code.zip

echo "📋 Creating backup with timestamp..."
aws s3 cp source-code.zip s3://\$SOURCE_BUCKET/backups/source-code-\$TIMESTAMP.zip

echo "✅ Upload complete! Pipeline should start automatically."
echo "🔗 Monitor: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"

rm source-code.zip
EOF
    
    chmod +x aws/scripts/upload-source.sh
    echo -e "${GREEN}✅ Created upload script: aws/scripts/upload-source.sh${NC}"
    
else
    echo -e "${RED}❌ Pipeline deployment failed${NC}"
    exit 1
fi