#!/bin/bash

# AWS CodePipeline Deployment Script for HelloWorld Smart Contract
# This script deploys the AWS infrastructure for CI/CD pipeline

set -e

# Configuration
STACK_NAME="helloworld-smart-contract-pipeline"
REGION="us-east-1"
TEMPLATE_FILE="aws/cloudformation/pipeline.yml"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Deploying HelloWorld Smart Contract Pipeline${NC}"
echo "=================================================="

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    echo -e "${RED}❌ AWS CLI is not installed. Please install it first.${NC}"
    exit 1
fi

# Check if user is logged in to AWS
if ! aws sts get-caller-identity &> /dev/null; then
    echo -e "${RED}❌ AWS credentials not configured. Please run 'aws configure' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ AWS CLI configured${NC}"

# Prompt for parameters
echo -e "${YELLOW}📝 Please provide the following information:${NC}"

read -p "GitHub Username: " GITHUB_OWNER
read -p "GitHub Repository Name [helloworld-contract]: " GITHUB_REPO
GITHUB_REPO=${GITHUB_REPO:-helloworld-contract}

read -p "GitHub Branch [main]: " GITHUB_BRANCH
GITHUB_BRANCH=${GITHUB_BRANCH:-main}

read -s -p "Infura API Key: " INFURA_API_KEY
echo

read -s -p "Ethereum Private Key (with 0x prefix): " PRIVATE_KEY
echo

# Validate inputs
if [[ -z "$GITHUB_OWNER" || -z "$INFURA_API_KEY" || -z "$PRIVATE_KEY" ]]; then
    echo -e "${RED}❌ All parameters are required${NC}"
    exit 1
fi

if [[ ! "$PRIVATE_KEY" =~ ^0x[a-fA-F0-9]{64}$ ]]; then
    echo -e "${RED}❌ Invalid private key format. Must be 64 hex characters with 0x prefix${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Parameters validated${NC}"

# Create GitHub token in AWS Secrets Manager (if not exists)
echo -e "${YELLOW}🔐 Setting up GitHub token in Secrets Manager...${NC}"
echo "Please create a GitHub Personal Access Token with 'repo' permissions"
echo "Visit: https://github.com/settings/tokens/new"
read -s -p "GitHub Personal Access Token: " GITHUB_TOKEN
echo

# Create or update GitHub token secret
aws secretsmanager create-secret \
    --name "github-token" \
    --description "GitHub Personal Access Token for CodePipeline" \
    --secret-string "{\"token\":\"$GITHUB_TOKEN\"}" \
    --region $REGION 2>/dev/null || \
aws secretsmanager update-secret \
    --secret-id "github-token" \
    --secret-string "{\"token\":\"$GITHUB_TOKEN\"}" \
    --region $REGION

echo -e "${GREEN}✅ GitHub token configured${NC}"

# Deploy CloudFormation stack
echo -e "${YELLOW}☁️  Deploying CloudFormation stack...${NC}"

aws cloudformation deploy \
    --template-file $TEMPLATE_FILE \
    --stack-name $STACK_NAME \
    --parameter-overrides \
        GitHubOwner=$GITHUB_OWNER \
        GitHubRepo=$GITHUB_REPO \
        GitHubBranch=$GITHUB_BRANCH \
        InfuraApiKey=$INFURA_API_KEY \
        PrivateKey=$PRIVATE_KEY \
    --capabilities CAPABILITY_IAM \
    --region $REGION

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Pipeline deployed successfully!${NC}"
    
    # Get outputs
    PIPELINE_NAME=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`PipelineName`].OutputValue' \
        --output text)
    
    ARTIFACTS_BUCKET=$(aws cloudformation describe-stacks \
        --stack-name $STACK_NAME \
        --region $REGION \
        --query 'Stacks[0].Outputs[?OutputKey==`ArtifactsBucket`].OutputValue' \
        --output text)
    
    echo ""
    echo -e "${GREEN}🎉 Deployment Complete!${NC}"
    echo "========================"
    echo "Pipeline Name: $PIPELINE_NAME"
    echo "Artifacts Bucket: $ARTIFACTS_BUCKET"
    echo "Region: $REGION"
    echo ""
    echo -e "${YELLOW}📋 Next Steps:${NC}"
    echo "1. Push your code to GitHub repository: $GITHUB_OWNER/$GITHUB_REPO"
    echo "2. The pipeline will automatically trigger on code changes"
    echo "3. Monitor the pipeline: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"
    echo "4. View build logs in CloudWatch"
    echo ""
    echo -e "${GREEN}🔗 Useful Links:${NC}"
    echo "• Pipeline Console: https://console.aws.amazon.com/codesuite/codepipeline/pipelines/$PIPELINE_NAME/view"
    echo "• CloudFormation Stack: https://console.aws.amazon.com/cloudformation/home?region=$REGION#/stacks/stackinfo?stackId=$STACK_NAME"
    echo "• Parameter Store: https://console.aws.amazon.com/systems-manager/parameters/?region=$REGION&tab=Table"
    
else
    echo -e "${RED}❌ Pipeline deployment failed${NC}"
    exit 1
fi