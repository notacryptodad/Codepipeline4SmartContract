# Security Pipeline Sequence Diagram

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant GH as GitHub
    participant CP as CodePipeline
    participant CB as CodeBuild
    participant LN as Lambda (Notification)
    participant SNS as SNS Topic
    participant ST as Security Team
    participant DDB as DynamoDB
    participant BC as Blockchain (Sepolia)
    participant LO as Lambda (Ownership)
    participant MA as Manual Approval

    Note over Dev,MA: Stage 1: Source Code Update
    Dev->>GH: 1. Push code changes
    GH->>CP: 2. Webhook triggers pipeline
    CP->>CP: 3. Pipeline starts execution

    Note over Dev,MA: Stage 2: Build and Deploy Smart Contract
    CP->>CB: 4. Start CodeBuild project
    CB->>CB: 5. Install dependencies (npm ci)
    CB->>CB: 6. Compile contracts (npm run compile)
    CB->>CB: 7. Run tests (npm run test)
    CB->>BC: 8. Deploy to Sepolia testnet
    BC-->>CB: 9. Return contract address
    CB->>CB: 10. Generate deployment-info.json
    CB-->>CP: 11. Build artifacts ready

    Note over Dev,MA: Stage 3: Notify Security Team
    CP->>LN: 12. Invoke notification Lambda
    LN->>DDB: 13. Store deployment state
    DDB-->>LN: 14. State stored
    LN->>SNS: 15. Publish security notification
    SNS->>ST: 16. Email notification sent
    LN-->>CP: 17. Notification complete

    Note over Dev,MA: Stage 4: Manual Security Approval (Loop if rejected)
    CP->>MA: 18. Wait for manual approval
    SNS->>ST: 19. Approval notification
    
    alt Security Review Passes
        ST->>MA: 20a. APPROVE - Security tests passed
        MA-->>CP: 21a. Approval granted
    else Security Review Fails
        ST->>MA: 20b. REJECT - Issues found
        MA-->>CP: 21b. Pipeline stopped
        Note over Dev,ST: Developer fixes issues, returns to Step 1
    end

    Note over Dev,MA: Stage 5: Transfer Contract Ownership
    CP->>LO: 22. Invoke ownership transfer Lambda
    LO->>DDB: 23. Update deployment state
    LO->>BC: 24. Execute transferOwnership() transaction
    BC-->>LO: 25. Transaction confirmed
    LO->>SNS: 26. Publish transfer notification
    SNS->>ST: 27. Ownership transfer notification
    LO-->>CP: 28. Transfer complete

    Note over Dev,MA: Stage 6: Final Security Confirmation
    CP->>MA: 29. Wait for final confirmation
    SNS->>ST: 30. Final confirmation notification
    ST->>BC: 31. Verify new ownership on blockchain
    BC-->>ST: 32. Ownership verified
    ST->>MA: 33. APPROVE - Ownership confirmed
    MA-->>CP: 34. Final approval granted
    CP->>CP: 35. Pipeline execution complete

    Note over Dev,MA: Success Path Complete
    CP->>SNS: 36. Pipeline success notification
    SNS->>ST: 37. Deployment completed notification
    SNS->>Dev: 38. Success notification to developer

    Note over Dev,MA: Error Handling
    alt Any Stage Fails
        CP->>SNS: 39. Failure notification
        SNS->>ST: 40. Alert security team
        SNS->>Dev: 41. Alert developer
        Note over Dev,ST: Investigation and remediation required
    end
```

## Pipeline Stages Breakdown

### Stage 1: Source
- **Trigger**: Developer pushes code to GitHub
- **Action**: GitHub webhook triggers CodePipeline
- **Output**: Source code artifacts

### Stage 2: Build & Deploy
- **Input**: Source code
- **Actions**: 
  - Compile smart contracts
  - Run test suite
  - Deploy to Sepolia testnet
- **Output**: Contract address, deployment artifacts

### Stage 3: Security Notification
- **Input**: Deployment artifacts
- **Actions**:
  - Store deployment state in DynamoDB
  - Send notification to security team via SNS
- **Output**: Security team alerted

### Stage 4: Manual Security Approval
- **Input**: Deployment information
- **Actions**:
  - Security team performs manual testing
  - Code review and vulnerability assessment
  - Manual approval/rejection decision
- **Output**: Approval status
- **Loop**: If rejected, returns to Stage 1

### Stage 5: Ownership Transfer
- **Input**: Approved deployment
- **Actions**:
  - Execute transferOwnership() on blockchain
  - Update deployment state
  - Notify security team of transfer
- **Output**: New contract owner set

### Stage 6: Final Confirmation
- **Input**: Ownership transfer completion
- **Actions**:
  - Security team verifies ownership change
  - Final manual approval
- **Output**: Deployment fully approved and complete

## Key Security Features

1. **Dual Approval Gates**: Two manual approval stages prevent unauthorized deployments
2. **Audit Trail**: All actions logged in DynamoDB with timestamps
3. **Notification System**: Security team notified at each critical stage
4. **Rollback Capability**: Pipeline can be stopped at any approval stage
5. **State Tracking**: Deployment state maintained throughout process
6. **Blockchain Verification**: Final ownership verification on-chain

## Failure Scenarios

- **Build Failure**: Pipeline stops, developer notified
- **Security Rejection**: Pipeline stops, requires code fixes
- **Ownership Transfer Failure**: Lambda handles error, security team notified
- **Network Issues**: Automatic retries, fallback notifications

This security-focused pipeline ensures no smart contract deployment occurs without explicit security team approval and verification.